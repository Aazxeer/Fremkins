var changePage = document.getElementById("submitButton");

changePage.addEventListener("click", createCharity);

function createCharity() {
    window.location.href = "charity.html";
}